
#ifndef global_plugin_name
#define global_plugin_name "Mac"
#endif
