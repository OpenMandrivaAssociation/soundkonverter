
#ifndef global_plugin_name
#define global_plugin_name "FFmpeg"
#endif

#ifndef global_plugin_version
#define global_plugin_version 1
#endif
