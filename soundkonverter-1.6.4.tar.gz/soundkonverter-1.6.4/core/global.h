
struct FormatInfo;

