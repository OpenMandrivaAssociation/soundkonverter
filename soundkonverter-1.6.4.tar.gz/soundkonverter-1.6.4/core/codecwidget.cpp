
#include "codecwidget.h"

CodecWidget::CodecWidget()
    : QWidget()
{}

CodecWidget::~CodecWidget()
{}

